package hanium.porong.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import hanium.porong.R;

public class DepressionTestActivity extends AppCompatActivity {
    private Button tButton;
    private int count = 0;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);


        tButton= (Button) findViewById(R.id.resultBtn);
        tButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final CheckBox cb1 = (CheckBox)findViewById(R.id.checkList1);
                final CheckBox cb2 = (CheckBox)findViewById(R.id.checkList2);
                final CheckBox cb3 = (CheckBox)findViewById(R.id.checkList3);
                final CheckBox cb4 = (CheckBox)findViewById(R.id.checkList4);
                final CheckBox cb5 = (CheckBox)findViewById(R.id.checkList5);
                final CheckBox cb6 = (CheckBox)findViewById(R.id.checkList6);
                final CheckBox cb7 = (CheckBox)findViewById(R.id.checkList7);
                final CheckBox cb8 = (CheckBox)findViewById(R.id.checkList8);
                final CheckBox cb9 = (CheckBox)findViewById(R.id.checkList9);
                final CheckBox cb10 = (CheckBox)findViewById(R.id.checkList10);
                final CheckBox cb11 = (CheckBox)findViewById(R.id.checkList11);
                final CheckBox cb12 = (CheckBox)findViewById(R.id.checkList12);
                final CheckBox cb13 = (CheckBox)findViewById(R.id.checkList13);
                final CheckBox cb14 = (CheckBox)findViewById(R.id.checkList14);
                final CheckBox cb15 = (CheckBox)findViewById(R.id.checkList15);
                final CheckBox cb16 = (CheckBox)findViewById(R.id.checkList16);
                final CheckBox cb17 = (CheckBox)findViewById(R.id.checkList17);
                final CheckBox cb18 = (CheckBox)findViewById(R.id.checkList18);
                final CheckBox cb19 = (CheckBox)findViewById(R.id.checkList19);
                final CheckBox cb20 = (CheckBox)findViewById(R.id.checkList20);
                final CheckBox cb21 = (CheckBox)findViewById(R.id.checkList21);






                if(cb1.isChecked() == true)
                    count++;
                if(cb2.isChecked() == true)
                    count++;
                if(cb3.isChecked() == true)
                    count++;
                if(cb4.isChecked() == true)
                    count++;
                if(cb5.isChecked() == true)
                    count++;
                if(cb6.isChecked() == true)
                    count++;
                if(cb7.isChecked() == true)
                    count++;
                if(cb8.isChecked() == true)
                    count++;
                if(cb9.isChecked() == true)
                    count++;
                if(cb10.isChecked() == true)
                    count++;
                if(cb11.isChecked() == true)
                    count++;
                if(cb12.isChecked() == true)
                    count++;
                if(cb13.isChecked() == true)
                    count++;
                if(cb14.isChecked() == true)
                    count++;
                if(cb15.isChecked() == true)
                    count++;
                if(cb16.isChecked() == true)
                    count++;
                if(cb17.isChecked() == true)
                    count++;
                if(cb18.isChecked() == true)
                    count++;
                if(cb19.isChecked() == true)
                    count++;
                if(cb20.isChecked() == true)
                    count++;
                if(cb21.isChecked() == true)
                    count++;



                Intent intent = new Intent(DepressionTestActivity.this, DepressionTestResultActivity.class);
                intent.putExtra("value", count);
                startActivity(intent);
            }
        });


    }
}

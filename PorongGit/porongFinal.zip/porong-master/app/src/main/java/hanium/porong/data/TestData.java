package hanium.porong.data;

public class TestData {
    //우울증 테스트 결과 데이터
}
